# rfid-attendance-system-raspberry-pi
Code to go alongside our RFID Attendance System tutorial.
