# Attendance-system-using-mysql-with-Raspberry-pi-and-RFID-RC522
Attendance system using mysql with Raspberry pi and RFID-RC522

In this project we are taking data from RFID reader which is connected to Node MCU V3 and saving it to PHPMYADMIN database running on Raspberry pi.

You can get it's video at https://www.youtube.com/watch?v=FMbKNQQqRhY and in case you need any help - you can contact us at info @ deligence.com. In case you need any embedded systems development or IoT work - you can send an email to us at sales @ deligence.com

Software Used:
Raspbian OS 
Arduino IDE 
My SQL Database 

Hardware Used: 
Raspberry pi 
Node MCU V3 
RFID Reader with Tag 
Jumper Wire 
